
<?php

include '../controller/Login_Process.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home </title>
    <link rel="stylesheet" href="..//design//home.css">
    

</head>
<body>
    <header>
        <h1>EVENT BOOKINGS</h1>
    </header>
    <nav>
        <ul>
            <li>My Profile</li>
            <li>Venue Details</li>

            <li><a href="index.php">Log Out</a></li>
        </ul>
        
    </nav>
        
         
    
    <footer>
        <p>Helpline: 123-456-7890</p>
        <p>For more information, visit here <a href="https://eb.gov.bd/">Directorate event bookings Services</a></p>
    </footer>
    <script src="..//js//home.js"></script>
</body>
</html>
